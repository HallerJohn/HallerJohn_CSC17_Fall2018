/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   MIN.h
 * Author: John Haller
 *
 * Created on November 26, 2018, 3:37 PM
 */

#ifndef MIN_H
#define MIN_H

template <class T>
T getMin (T a,T b){
    return (a<b?a:b);
}

#endif /* MIN_H */

